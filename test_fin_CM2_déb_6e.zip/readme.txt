Une fois le dossier "" d�zip�, lancez le fichier "test6.exe".
*Cr�� sous visual Basic 6. 
*vous aurez besoin des biblioth�ques sp�cifiques au visual basic,
� placer dans le system32 et le syswow64 de windows.
Vous les trouverez dans "https://sourceforge.net/"